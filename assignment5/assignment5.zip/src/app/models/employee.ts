export class Employee {
  _id:number;
  FirstName:string;
  LastName:string;
  completed:boolean;
}
