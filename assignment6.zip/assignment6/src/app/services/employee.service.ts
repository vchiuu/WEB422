import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders} from '@angular/common/http';

import { Employee } from '../models/employee';
import { EmployeeRaw } from '../models/employeeRaw';

const httpOptions = {
  headers: new HttpHeaders({
      'Content-Type': 'application/json'
  })
}

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  getEmployees():Observable<Employee[]> {
    return this.http.get<Employee[]>('http://teams-api-data.herokuapp.com/employees');
  }

  saveEmployee(employee: EmployeeRaw):Observable<any>{
    return this.http.put<any>("http://teams-api-data.herokuapp.com/employee/" + employee._id, employee);
  }

  getEmployee(id: string):Observable<EmployeeRaw[]>{
    return this.http.get<EmployeeRaw[]>("http://teams-api-data.herokuapp.com/employee/" + id);
  }
}
